import time
for i in range(10, 0, -1):
    print(i, end=" ")
    time.sleep(1)
print("발사! ")
