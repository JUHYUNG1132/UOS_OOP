print(dir([1, 2, 3]))
print(complex(4, 2))
