import calendar

cal = calendar.month(2016, 8)
print(cal)