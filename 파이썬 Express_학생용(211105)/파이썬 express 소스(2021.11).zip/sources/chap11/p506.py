x = 64
y = bin(x)  
print(y)  				# 출력 0b1000000


x =  10  
print(eval('x + 1'))

exp = input("파이썬의 수식을 입력하시오: ")
print(eval(exp))

x = 10
y = 5
print(eval('x+y'))
