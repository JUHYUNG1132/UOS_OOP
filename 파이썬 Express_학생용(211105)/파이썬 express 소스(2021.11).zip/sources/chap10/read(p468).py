infile = open("input.txt", "r")
s = infile.read()
print(s)
infile.close()