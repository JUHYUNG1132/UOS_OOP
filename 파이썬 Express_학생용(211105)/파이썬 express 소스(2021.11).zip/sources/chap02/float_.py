﻿SQMETER_PER_P = 3.3

area = float(input ("면적(제곱미터):"))
py = area / SQMETER_PER_P
print(py, "평")