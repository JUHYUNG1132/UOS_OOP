﻿SQMETER_PER_P = 3.3

area = eval(input ("면적(제곱미터):"))
py = area / SQMETER_PER_P
print("%.2f" % py, "평") 	# 출력 7.76 평
