﻿s1 = input("첫 번째 정수를 입력하시오:")
x = int(s1)			# 문자열을 정수로 변환한다. 
s2 = input("두 번째 정수를 입력하시오:")
y = int(s2)			# 문자열을 정수로 변환한다. 
sum = x + y
print("합은 ", sum)
