﻿import turtle
t = turtle.Turtle()
t.shape("turtle")

t.circle(100)      
t.fd(30)		
t.circle(100)      	
t.fd(30)
t.circle(100)      	

turtle.mainloop()
turtle.bye()
