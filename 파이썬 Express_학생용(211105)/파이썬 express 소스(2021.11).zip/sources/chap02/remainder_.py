﻿p = 7
q = 4
print("나눗셈의 몫=", p // q)
print("나눗셈의 나머지=", p % q)
