﻿a = "Kim"
b = "Park"
acronym = a[0] + "과" + b[0]
print(acronym)