﻿##
#	이 프로그램은 원기둥의 부피를 계산한다. 
#
# 원주율을 나타내는 상수를 정의한다. 
PI = 3.14

# 변수를 정의한다. 
radius = 5
height = 10

# 부피를 계산한다. 
volume = PI * radius * radius * height

# 결과를 출력한다. 
print("반지름=", radius, "높이=", height, "원의 면적=", volume)
