﻿price = 12345
tax = price * 0.075
tax = round(tax, 2)
print(tax)
