﻿##
#	이 프로그램은 사용자와 친근하게 대화한다. 
#
print("안녕하세요?")
name = input("이름이 어떻게 되시나요? ")
print("만나서 반갑습니다. " + name + "씨")

print("이름의 길이는 다음과 같군요:", len(name))

age = int(input("나이가 어떻게 되나요? "))
print("내년이면 "+ str(age+1) + "이 되시는군요.")
