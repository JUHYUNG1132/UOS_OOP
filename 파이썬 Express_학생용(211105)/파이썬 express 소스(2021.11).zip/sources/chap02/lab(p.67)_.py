﻿import turtle
t = turtle.Turtle()
t.shape("turtle")

radius = 50
t.circle(radius)      	
t.fd(30)
t.circle(radius)      	
t.fd(30)
t.circle(radius)      	

turtle.mainloop()
turtle.bye()	
