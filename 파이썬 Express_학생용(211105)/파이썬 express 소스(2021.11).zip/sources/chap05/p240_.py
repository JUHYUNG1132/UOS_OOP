﻿gx = 100

def myfunc() :
    gx = 200
    print(gx)

myfunc()
print(gx)
