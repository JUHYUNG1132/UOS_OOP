﻿def sub(x, y, z):
	print("x=", x, "y=", y, "z=", z)
