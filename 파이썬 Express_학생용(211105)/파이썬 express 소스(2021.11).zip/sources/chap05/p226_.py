﻿def print_birthday(name) :
	print("생일축하 합니다! ");
	print("생일축하 합니다! ");
	print("사랑하는 ", name, "의");
	print("생일축하 합니다! \n");

print_birthday("홍길동")
