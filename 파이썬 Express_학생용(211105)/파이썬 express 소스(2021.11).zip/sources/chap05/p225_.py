﻿def sub():
	return 1, 2, 3

a, b, c = sub()
print(a, b, c)
