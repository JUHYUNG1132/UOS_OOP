﻿gx = 100

def myfunc():
  print(gx)

myfunc()
print(gx)
