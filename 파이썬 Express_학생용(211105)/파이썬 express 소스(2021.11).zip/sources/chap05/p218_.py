﻿def varfunc(*args ):   
	print (args)

print("하나의 값으로 호출")
varfunc(10)
print("여러 개의 값으로 호출")
varfunc(10, 20, 30)
