﻿heroes = [ "아이언맨", "토르", "헐크" ]
heroes.remove("토르")

if "토르" in heroes:
	heroes.remove("토르")
