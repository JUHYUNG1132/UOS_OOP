﻿list1 = [ 1, 2, 3 ]
list2 = [ 1, 2, 3 ]
print(list1 == list2)		# True

list1 = [ 3, 4, 5 ]
list2 = [ 1, 2, 3 ]
print(list1 > list2)  		# True
