﻿numbers = [ 10, 20, 30, 40, 50, 60, 70, 80, 90 ]
sublist = numbers[2:7]
print(slice)

numbers[:3]	# [10, 20, 30]

numbers[3:]	# [40, 50, 60, 70, 80, 90]

numbers[:]	# [10, 20, 30, 40, 50, 60, 70, 80, 90]

new_numbers = numbers[:]
