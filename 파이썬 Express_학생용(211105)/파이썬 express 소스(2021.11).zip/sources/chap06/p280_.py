﻿def func1(x):
    x = 42
    print( "x=",x," id=",id(x))

y = 10
func1(y)
print( "y=",y," id=",id(y))
