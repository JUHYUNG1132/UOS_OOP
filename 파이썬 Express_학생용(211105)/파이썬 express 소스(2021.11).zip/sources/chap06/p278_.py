﻿s = "Monty Python"
print(s[0])			# M
print(s[6:10])			# Pyth
print(s[-12:-7])		# Monty
