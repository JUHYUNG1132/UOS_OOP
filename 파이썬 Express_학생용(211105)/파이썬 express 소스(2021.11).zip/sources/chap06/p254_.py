﻿temps = [28, 31, 33, 35, 27, 26, 25] 
print(temps[3])
e = temps[3]
