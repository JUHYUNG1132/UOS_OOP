﻿numbers = [x for x in range(100) if x % 2 == 0 and x % 3 == 0]
print(numbers)
