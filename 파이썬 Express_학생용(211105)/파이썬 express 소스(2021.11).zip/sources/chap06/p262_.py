﻿values = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
min(values)		# 1
max(values)		# 10

a = [ 3, 2, 1, 5, 4 ]
a.sort()			# [1, 2, 3, 4, 5]

heroes =['아이언맨','헐크','토르']
heroes.sort()
print(heroes)

a =[3,2,1,5,4 ]
a.sort(reverse=True)
print(a)
