﻿heroes = [ ] 				# 공백 리스트를 생성한다. 
heroes.append("아이언맨")		# 리스트에 ”아이언맨“을 추가한다. 
heroes.append("토르")			# 리스트에 ”토르“를 추가한다. 
print(heroes)


