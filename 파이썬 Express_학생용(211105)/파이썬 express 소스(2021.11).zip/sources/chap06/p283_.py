﻿squares = [ x*x for x in range(10) ]
print(squares)

squares = []

for x in range(10):
    squares.append(x*x)
