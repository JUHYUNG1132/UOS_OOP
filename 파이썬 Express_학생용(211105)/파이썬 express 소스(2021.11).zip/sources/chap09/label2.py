from tkinter import *

window = Tk()
photo = PhotoImage(file="d://fig.png")
Label(window, image=photo).pack()

window.mainloop()
