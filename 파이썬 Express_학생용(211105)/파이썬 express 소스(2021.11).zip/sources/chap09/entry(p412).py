from tkinter import *				
window = Tk()					

entry = Entry(window, fg="black", bg="yellow", width=80)

entry.pack()					
window.mainloop()	