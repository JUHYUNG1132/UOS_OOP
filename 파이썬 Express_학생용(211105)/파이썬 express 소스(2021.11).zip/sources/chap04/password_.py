﻿password = ""
while password != "pythonisfun":
	password = input("암호를 입력하시오: ")
print("로그인 성공")