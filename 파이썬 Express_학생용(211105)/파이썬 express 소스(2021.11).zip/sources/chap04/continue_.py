﻿for i in range(1, 11):
    if i%3 == 0 :		# 3의 배수이면
        continue		# 다음 반복을 시작한다. 
    print(i, end=" ")		# 줄바꿈을 하지 않고 스페이스만 출력한다. 
