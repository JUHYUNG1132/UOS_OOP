﻿sum = 0
n = 10
for i in range(1, n+1) :				
	sum = sum + i
print("합=", sum)	
