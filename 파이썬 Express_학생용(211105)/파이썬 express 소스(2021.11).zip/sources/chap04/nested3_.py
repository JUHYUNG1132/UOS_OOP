﻿adj = ["small", "medium", "large"]
nouns = ["apple", "banana", "grape"]

for x in adj:
  for y in nouns:
    print(x, y)	
