﻿for y in range(5) :
	for x in range(10) :
		print("*", end="" )
	print("")
