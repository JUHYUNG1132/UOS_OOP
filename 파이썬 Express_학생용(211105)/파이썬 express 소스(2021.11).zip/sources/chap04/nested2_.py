﻿for y in range(1, 6) :
	for x in range(y) :
		print("*", end="" )
	print("")			# 내부 반복문이 종료될 때마다 실행
