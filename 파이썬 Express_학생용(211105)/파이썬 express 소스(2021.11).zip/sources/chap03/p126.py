number = int(input("정수를 입력하시오: "))

if number % 2 == 0 :
    print("짝수입니다.")
else:
    print("홀수입니다.")
