from math import sqrt

n = sqrt(3.0)
if n*n == 3.0 :
	print("sqrt(3.0)*sqrt(3.0)은 3.0과 같다. ")
else :
	print("sqrt(3.0)*sqrt(3.0)은 3.0과 같지 않다. ")