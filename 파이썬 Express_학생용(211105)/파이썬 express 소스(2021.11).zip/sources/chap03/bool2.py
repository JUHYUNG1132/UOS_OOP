price = 30000
expensive = price > 20000 	# expensive가 부울 변수이다. 
if  expensive :		# 관계 수식 대신에 부울 변수가 들어가도 된다. 
	shipping_cost = 0
else :
	shipping_cost = 3000