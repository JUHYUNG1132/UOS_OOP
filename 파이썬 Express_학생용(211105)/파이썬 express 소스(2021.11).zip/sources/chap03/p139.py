score = 90
if score >= 60 :
	print("학점 D")
elif score >= 70 :
	print("학점 C")
elif score >= 80 :
	print("학점 B")
elif score >= 90 :
	print("학점 A")
else :
	print("학점 F")