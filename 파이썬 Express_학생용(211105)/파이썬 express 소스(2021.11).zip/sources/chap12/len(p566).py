mylist = [1, 2, 3]		# 리스트
print("리스트의 길이=", len(mylist))

s = "This is a sentense"	# 문자열 
print("문자열의 길이=", len(s))

d = {'aaa': 1, 'bbb': 2}	# 딕셔너리
print("딕셔너리의 길이=", len(d))