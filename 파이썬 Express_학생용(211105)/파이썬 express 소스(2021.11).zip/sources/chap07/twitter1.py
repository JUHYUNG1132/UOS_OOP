t = "Python is very easy and powerful!"

length = len(t.split(" "))
print(length)