capitals ={"Korea":"Seoul","USA":"Washington","UK":"London"} 
for key in capitals :
        print( key, end=" ")