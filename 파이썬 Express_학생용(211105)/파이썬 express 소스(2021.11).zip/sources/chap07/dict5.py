capitals ={"Korea":"Seoul","USA":"Washington","UK":"London"} 

capitals.clear()
if len(capitals)==0 :
	print("딕셔너리에 항목이 있음")
else:
	print("딕셔너리가 비어 있음")
