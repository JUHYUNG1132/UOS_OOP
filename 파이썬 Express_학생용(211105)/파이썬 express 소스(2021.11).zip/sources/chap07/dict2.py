capitals ={"Korea":"Seoul","USA":"Washington","UK":"London"} 
if "France" in capitals :
	print( "딕셔너리에 포함됨" )
else: 
	print( "딕셔너리에 포함되지 않음" )
