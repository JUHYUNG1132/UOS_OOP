capitals ={"Korea":"Seoul","USA":"Washington","UK":"London"}
print( capitals.keys())
print( capitals.values())