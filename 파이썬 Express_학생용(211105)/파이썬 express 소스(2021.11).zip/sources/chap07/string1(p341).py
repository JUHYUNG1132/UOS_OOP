a = input("문자열을 입력하시오: ")
b = input("문자열을 입력하시오: ")
if( a < b ):
	print(a, "가 앞에 있음")
else:
	print(b, "가 앞에 있음")
