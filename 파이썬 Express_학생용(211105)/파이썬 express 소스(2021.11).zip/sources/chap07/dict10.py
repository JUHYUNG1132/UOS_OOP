capitals ={"Korea":"Seoul","USA":"Washington","UK":"London"} 
for key in sorted( capitals.keys()):
	print(key, end=" ")