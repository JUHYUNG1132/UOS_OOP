A ={"apple","banana","grape"}
B ={"apple","banana","grape","kiwi"}

if A < B : 			# 또는 A.issubset(B) :
	print("A는 B의 부분 집합입니다.")