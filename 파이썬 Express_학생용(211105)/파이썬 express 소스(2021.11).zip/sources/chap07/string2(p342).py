x = 25
y = 98
prod = x * y
print(f"{x}과 {y}의 곱은 {prod}")