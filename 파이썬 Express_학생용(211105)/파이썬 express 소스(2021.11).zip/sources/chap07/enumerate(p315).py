fruits =["apple","banana","grape"]
for index, value in enumerate(fruits):
	print(index, value)

fruits =["apple","banana","grape"]
result =list(enumerate(fruits))
print(result)
