fruits =["apple","orange","banana"]
dic ={ f :len(f)for f in fruits }
print( dic )