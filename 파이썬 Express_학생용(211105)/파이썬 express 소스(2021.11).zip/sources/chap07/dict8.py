capitals ={"Korea":"Seoul","USA":"Washington","UK":"London"} 
for key, value in capitals.items():
        print( key,":", value )
