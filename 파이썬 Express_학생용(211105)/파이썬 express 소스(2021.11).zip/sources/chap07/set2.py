fruits ={"apple","banana","grape"}
for x in sorted(fruits):
	print(x, end=" ")