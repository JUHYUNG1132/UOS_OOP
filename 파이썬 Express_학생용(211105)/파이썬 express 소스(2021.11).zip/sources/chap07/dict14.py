dic1 ={"One":1,"Two":2,  "Three":3 }
dic2 ={ n : w for w , n in dic1.items()}
print( dic2 )