fruits = { "apple", "banana", "grape" }
if "apple" in fruits:
	print("집합 안에 apple이 있습니다.")