capitals ={"Korea":"Seoul","USA":"Washington","UK":"London"} 
capitals.update({"France":"Paris","Germany":"Berlin"})
print(capitals)